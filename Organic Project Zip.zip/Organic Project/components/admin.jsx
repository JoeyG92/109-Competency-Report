import "./admin.css";

const Admin = () => {
    return(
        <div className="admin-page">
            <div className="sections-container">
                <section className="sec-products">
                    <h4>Manage Products</h4>

                        <div className="form">
                            <div className="my-control">
                                <label></label>
                                <input type="text" />
                            </div>
                        </div>
                </section>

                <section className="sec-coupons">
                    <h4> Manage Coupon Codes</h4>
                </section>
            </div>
        </div>
    )
}

export default Admin;